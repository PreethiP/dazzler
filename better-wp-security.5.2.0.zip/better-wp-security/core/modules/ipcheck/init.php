<?php

class ITSEC_IP_Check_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'ip-check';
	protected $_name = 'IP Check';
	protected $_desc = 'IP Check.';
}
new ITSEC_IP_Check_Module_Init();
