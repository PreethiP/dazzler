<?php

class ITSEC_Core_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'core';
	protected $_name = 'Core';
	protected $_desc = 'Core.';
}
new ITSEC_Core_Module_Init();
