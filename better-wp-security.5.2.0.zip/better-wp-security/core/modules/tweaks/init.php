<?php

class ITSEC_Tweaks_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'tweaks';
	protected $_name = 'Tweaks';
	protected $_desc = 'Tweaks.';
}
new ITSEC_Tweaks_Module_Init();
